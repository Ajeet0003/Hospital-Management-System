package com.shms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartHospitalManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartHospitalManagementSystemApplication.class, args);
	}

}
