package com.shms.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.shms.dao.AppointmentRepository;
import com.shms.entities.Appointment;
//import com.shms.dao.AppointmentRepository;
import com.shms.dao.PatientRepository;
import com.shms.entities.Patient;


@Controller
@RequestMapping("/patient")
public class PatientController {
	
	@Autowired
	private PatientRepository patientRepository;
	
	@Autowired
	private AppointmentRepository appointmentRepository;
	
	
	//method for adding common data to response
	@ModelAttribute
	public void addCommonData(Model model,Principal principal) {
		String patientName=principal.getName();
		System.out.println("patient name"+patientName);
		
		Patient patient=patientRepository.getPatientByUserName(patientName);
		System.out.println(patient);
		
		model.addAttribute("patient",patient);
		
	}
	
	
	//Dashboard home
	@RequestMapping("/index")
	public String dashboard(Model model,Principal principal) {
		
		model.addAttribute("title","patient Dashboard");
		return "/normal/patient_dashboard";
	}
	
	// open add form handler
	
	@GetMapping("/book-appointment")
	public String openBookAppointment(Model model) {
		
		model.addAttribute("title","book appointment");
		model.addAttribute("appointment",new Appointment());
		return "/normal/book_appointment_form";
	}
	
}
